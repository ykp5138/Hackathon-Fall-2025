1. Get your own OpenRouter API key from https://openrouter.ai.
2. Create a .env file and add:
   OPENROUTER_API_KEY=sk-yourkeyhere
3. Run:
   pip install -r requirements.txt
   python lol_overlay.py